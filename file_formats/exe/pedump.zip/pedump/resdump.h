void DumpResourceSection(DWORD base, PIMAGE_NT_HEADERS pNTHeader);
